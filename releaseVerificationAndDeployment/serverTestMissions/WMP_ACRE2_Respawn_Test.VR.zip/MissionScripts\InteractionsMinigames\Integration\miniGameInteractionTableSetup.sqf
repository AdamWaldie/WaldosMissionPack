/*
 * Adds an opt-in Field Equipment picker to a party table without joining its multiplayer
 * vote/ready state. Entries are ids or [id, config, presentation] rows. Empty
 * configs use the table's curated difficulty; explicit configs remain custom.
 *
 * Example:
 * [this, ["repair", "radiotune", ["circuit", [4,3,0], [["preset","generatorBreaker"]]]]]
 *     call Waldo_fnc_MiniGameInteractionTableSetup;
 */
params [
    ["_table", objNull, [objNull]],
    ["_procedures", ["wirecut", "minesweeper", "keypad", "lockpick", "circuit", "repair", "radiotune", "pressure", "sequence", "commandinput"], [[]]],
    ["_options", [], [[], createHashMap]]
];
if (isNull _table) exitWith {false};

private _optionPairs = if (typeName _options == "HASHMAP") then {
    private _pairs = [];
    {_pairs pushBack [_x, _options get _x];} forEach keys _options;
    _pairs
} else {+_options};
private _getOption = {
    params ["_key", "_default"];
    private _value = _default;
    {if ((_x select 0) == _key) exitWith {_value = _x select 1;};} forEach _optionPairs;
    _value
};
private _difficultyValue = ["difficulty", "standard"] call _getOption;
private _difficulty = if (typeName _difficultyValue == "STRING") then {toLower _difficultyValue} else {"standard"};
if !(_difficulty in ["easy", "standard", "hard", "expert"]) then {_difficulty = "standard";};

private _normal = [];
{
    if (typeName _x == "STRING") then {
        private _id = toLower _x;
        _normal pushBack [_id, [_id, _difficulty] call Waldo_fnc_MiniGameEquipmentDifficultyConfig, [], _difficulty];
    } else {
        if (typeName _x == "ARRAY" && {(count _x) > 0}) then {
            private _id = toLower (_x param [0, "wirecut"]);
            private _config = _x param [1, []];
            private _entryDifficulty = "custom";
            if (_config isEqualTo []) then {
                _config = [_id, _difficulty] call Waldo_fnc_MiniGameEquipmentDifficultyConfig;
                _entryDifficulty = _difficulty;
            };
            _normal pushBack [_id, _config, _x param [2, []], _entryDifficulty];
        };
    };
} forEach _procedures;
if ((count _normal) == 0) exitWith {false};

_table setVariable ["Waldo_IMG_TableProcedures", _normal];
if (!hasInterface) exitWith {true};
private _icon = ["icon", "\a3\ui_f_oldman\data\IGUI\Cfg\holdactions\repair_ca.paa"] call _getOption;
private _actionTitle = ["actionTitle", "Field Equipment"] call _getOption;
private _distance = ["distance", 4] call _getOption;
private _aceAvailable = isClass (configFile >> "CfgPatches" >> "ace_interact_menu")
    && {!(isNil "ace_interact_menu_fnc_createAction")}
    && {!(isNil "ace_interact_menu_fnc_addActionToObject")};
if (_aceAvailable && {!(_table getVariable ["Waldo_IMG_TableACEActionInstalled", false])}) then {
    private _action = [
        "Waldo_IMG_FieldEquipment",
        _actionTitle,
        _icon,
        {[_this select 0] call Waldo_fnc_MiniGameEquipmentPicker;},
        {
            params ["_target", "_player"];
            !isNull _target && {alive _player} && {isNull (uiNamespace getVariable ["Waldo_MG_ActiveChallengeDisplay", displayNull])}
        }
    ] call ace_interact_menu_fnc_createAction;
    [_table, 0, ["ACE_MainActions"], _action] call ace_interact_menu_fnc_addActionToObject;
    _table setVariable ["Waldo_IMG_TableACEActionInstalled", true];
};
if (_aceAvailable) then {
    private _oldVanillaId = _table getVariable ["Waldo_IMG_TableActionId", -1];
    if (_oldVanillaId >= 0) then {_table removeAction _oldVanillaId;};
    _table setVariable ["Waldo_IMG_TableActionId", -1];
    _table setVariable ["Waldo_IMG_TableVanillaActionInstalled", false];
};
if (!_aceAvailable && {!(_table getVariable ["Waldo_IMG_TableVanillaActionInstalled", false])}) then {
    private _id = _table addAction [
        _actionTitle,
        {[_this select 0] call Waldo_fnc_MiniGameEquipmentPicker;},
        [], 1.55, true, true, "",
        "isNull (uiNamespace getVariable ['Waldo_MG_ActiveChallengeDisplay', displayNull])",
        _distance
    ];
    _table setVariable ["Waldo_IMG_TableActionId", _id];
    _table setVariable ["Waldo_IMG_TableVanillaActionInstalled", true];
};
true
