/*
 * Author: WaldoTheWarfighter, Val
 * Evaluates all registered hazard zones for the local player and applies profile effects.
 *
 * This function runs only on each player's client from Waldo_fnc_HazardInit. Exposure and zone
 * transition state are local to that player; registered zone definitions are shared/JIP-replayed.
 * Optional entry/exit cards use the WMP notification UI once per transition. Live exposure uses
 * one continuously updated specialist HUD rather than notification lanes. Profiles may require a
 * carried/worn detector, nearby detector object or custom awareness condition before either form
 * of information is visible; physical exposure and damage still apply. Profile onEnter, onExit and
 * onTick callbacks continue to run locally. The status panel shows one combined line per hazard
 * `type` (summed across every zone/emitter contributing to it), not one line per zone key - all
 * three shipped radiation presets share type "RADIATION" specifically so their dose reads as one
 * figure. The panel and the underlying physical exposure are deliberately different things: exposure
 * keeps accumulating/decaying at its own configured `rate`/`decay` regardless of whether the panel is
 * on screen (still driving damageThresholds/fatalExposure later), but the panel itself behaves like a
 * live Geiger counter - it follows the player being inside a zone of that type, and only lingers
 * Waldo_Hazard_StatusGraceSeconds after the player leaves every zone of that type, not until the
 * numeric exposure value happens to decay to zero (which can legitimately take much longer). Currently
 * called by the HazardInit loop and directly by the full-pack function station.
 * Locality and authority: Interface-client only. It consumes JIP-replayed zone definitions and
 * mutates only the executing player's exposure, effects, callbacks and presentation.
 *
 * Arguments:
 * 0: interval <NUMBER> - seconds represented by this tick
 *
 * Return Value:
 * Nothing
 *
 * Example:
 * [1] call Waldo_fnc_HazardTick;
 * Result: Applies one second-equivalent exposure update and refreshes that player's hazard UI.
 * Current callers: Waldo_fnc_HazardInit loop and the full-pack audit function station.
 */

params [["_interval", 1, [0]]];
if !(hasInterface && {alive player}) exitWith {};
// Exposure belongs to one concrete player object, never merely to the client missionNamespace.
// This synchronous guard closes the small cross-machine/event-order window where the evaluator can
// see a new respawned unit before EntityRespawned has performed its local cleanup.
if !((missionNamespace getVariable ["Waldo_Hazard_LocalPlayerObject", objNull]) isEqualTo player) then {
    [] call Waldo_fnc_HazardResetLocal;
};

private _exposures = missionNamespace getVariable ["Waldo_Hazard_LocalExposure", createHashMap];
private _previousInside = missionNamespace getVariable ["Waldo_Hazard_LocalInside", createHashMap];
private _previousStages = missionNamespace getVariable ["Waldo_Hazard_LocalDamageStages", createHashMap];
private _activeText = [];
private _zoneDiagnostics = [];
// Multiple zones/emitters commonly share one hazard `type` (all three shipped radiation presets
// use "RADIATION" specifically so their dose is meant to read as one combined figure). Collect
// contributions per type here and emit exactly one status line per type after the loop below,
// instead of one line per zone key.
private _typeAggregates = createHashMap;
// Panel visibility is tracked separately from the exposure value itself - see the header note.
// This is the "was any zone of this type showable-inside within the grace window" clock.
private _typeLastInside = missionNamespace getVariable ["Waldo_Hazard_LocalTypeLastInside", createHashMap];
private _graceSeconds = missionNamespace getVariable ["Waldo_Hazard_StatusGraceSeconds", 6];

{
    _x params ["_key", "_area", "_profile"];
    private _inside = false;
    private _intensity = 0;

    if (_area isEqualType []) then {
        private _centre = _area select 0;
        private _axisA = (_area select 1) max 1;
        private _axisB = if (count _area >= 5) then {(_area select 2) max 1} else {_axisA};
        _inside = if (count _area >= 5) then {player inArea [_centre, _axisA, _axisB, _area select 3, _area select 4]} else {player distance2D _centre <= _axisA};
        if (_inside) then {_intensity = 1 - ((player distance2D _centre) / (_axisA max _axisB))};
    };
    if (_area isEqualType "") then {
        _inside = player inArea _area;
        if (_inside) then {
            private _radius = selectMax (markerSize _area) max 1;
            _intensity = 1 - ((player distance2D getMarkerPos _area) / _radius);
        };
    };
    if (_area isEqualType objNull && {isNull _area}) then {
        // A moving-emitter anchor (Waldo_fnc_HazardRegisterEmitter) can be deleted mid-mission
        // (vehicle wreck cleanup, a scripted deleteVehicle) without the zone being unregistered.
        // distance2D's behaviour against objNull isn't something to rely on for a damage gate -
        // treat a null anchor as "not inside" rather than risk every player reading as inside a
        // hazard that no longer has a real position.
        _inside = false;
        _intensity = 0;
    };
    if (_area isEqualType objNull && {!isNull _area}) then {
        if (_area isKindOf "EmptyDetector") then {
            _inside = player inArea _area;
            if (_inside) then {
                private _triggerSize = triggerArea _area;
                private _radius = ((_triggerSize select 0) max (_triggerSize select 1)) max 1;
                _intensity = 1 - ((player distance2D _area) / _radius);
            };
        } else {
            private _radius = (_profile getOrDefault ["emitterRadius", 10]) max 1;
            _inside = player distance2D _area <= _radius;
            if (_inside) then {_intensity = 1 - ((player distance2D _area) / _radius)};
        };
    };

    private _altitude = getPosATL player select 2;
    if (_inside && {_altitude < (_profile getOrDefault ["minimumAltitudeATL", -1e10]) || {_altitude > (_profile getOrDefault ["maximumAltitudeATL", 1e10])}}) then {
        _inside = false;
        _intensity = 0;
    };

    if (toUpperANSI (_profile getOrDefault ["intensityMode", "LINEAR"]) == "CONSTANT" && {_inside}) then {_intensity = 1};

    _intensity = if (_inside) then {
        (_intensity max (_profile getOrDefault ["minimumIntensity", 0.05])) min 1
    } else {
        0
    };
    private _distance = if (_area isEqualType objNull) then {player distance2D _area} else {
        if (_area isEqualType "") then {player distance2D getMarkerPos _area} else {player distance2D (_area select 0)}
    };
    _zoneDiagnostics pushBack [_key, _inside, _distance, _intensity, typeName _area];
    private _exposure = _exposures getOrDefault [_key, 0];
    if (_inside) then {
        private _protection = [player, _profile, _key] call Waldo_fnc_HazardProtectionFactor;
        _exposure = _exposure + ((_profile getOrDefault ["rate", 1]) * _intensity * _protection * _interval);
        {
            _exposures set [_x, ((_exposures getOrDefault [_x, 0]) - ((_profile getOrDefault ["decontaminationRate", 1]) * _interval)) max 0];
        } forEach (_profile getOrDefault ["reducesChannels", []]);
    } else {
        _exposure = (_exposure - ((_profile getOrDefault ["decay", 0.1]) * _interval)) max 0;
    };
    _exposure = _exposure min (_profile getOrDefault ["maximumExposure", 1e10]);
    _exposures set [_key, _exposure];
    private _awarenessConfigured =
        !((_profile getOrDefault ["detectorItems", []]) isEqualTo [])
        || !((_profile getOrDefault ["detectorObjects", []]) isEqualTo [])
        || ("awarenessCondition" in _profile);
    private _awareResult = [player, _key, _profile, _inside, _exposure] call Waldo_fnc_HazardAwareness;
    // A mission-supplied awareness callback is not allowed to break the complete hazard tick.
    // Invalid callback output hides detector-gated information while physical danger continues.
    private _aware = false;
    if !(isNil "_awareResult") then {
        if (_awareResult isEqualType true) then {_aware = _awareResult};
    };
    private _showNotifications = !(_profile getOrDefault ["requireAwarenessForNotifications", _awarenessConfigured]) || {_aware};
    private _showLiveStatus = !(_profile getOrDefault ["requireAwarenessForStatus", _awarenessConfigured]) || {_aware};

    private _wasInside = _previousInside getOrDefault [_key, false];
    if (_inside != _wasInside) then {
        private _transition = _profile getOrDefault [if (_inside) then {"onEnter"} else {"onExit"}, {}];
        if (_transition isEqualType "") then {_transition = missionNamespace getVariable [_transition, {}]};
        if (_transition isEqualType {}) then {[player, _key, _profile] call _transition};
        diag_log format ["[WMP HAZARD] Player transition: zone='%1' inside=%2 exposure=%3.", _key, _inside, _exposure];
        if (_showNotifications && {_profile getOrDefault ["notifyTransitions", missionNamespace getVariable ["Waldo_Hazard_NotifyTransitions", true]]}) then {
            private _label = _profile getOrDefault ["label", _profile getOrDefault ["type", "Hazardous Area"]];
            private _messageKey = ["exitMessage", "enterMessage"] select _inside;
            private _defaultMessage = ["You have left the hazardous zone.", "You have entered a hazardous zone."] select _inside;
            private _state = [["exitState", "INFO"], ["enterState", "WARNING"]] select _inside;
            [
                _label,
                _profile getOrDefault [_messageKey, _defaultMessage],
                _profile getOrDefault _state,
                format ["HAZARD_%1", _key],
                _profile getOrDefault ["notificationDuration", missionNamespace getVariable ["Waldo_Hazard_NotificationDuration", 6]]
            ] call Waldo_fnc_FeatureNotifyLocal;
        };
        _previousInside set [_key, _inside];
    };

    if (_showLiveStatus && {(_profile getOrDefault ["showStatus", missionNamespace getVariable ["Waldo_Hazard_ShowStatus", true]])} && {_inside || {_exposure > 0}}) then {
        private _type = _profile getOrDefault ["type", _profile getOrDefault ["label", "HAZARD"]];
        private _label = _profile getOrDefault ["label", _type];
        private _entry = _typeAggregates getOrDefault [_type, [_label, 0]];
        _entry set [1, (_entry select 1) + _exposure];
        _typeAggregates set [_type, _entry];
        // Reset this type's grace clock every tick the player is actually inside one of its zones -
        // like a Geiger counter, the panel should track presence, not the slower-decaying dose figure.
        if (_inside) then {_typeLastInside set [_type, diag_tickTime];};
    };

    private _damage = 0;
    private _damageStage = -1;
    {
        _x params ["_threshold", "_tickDamage"];
        if (_exposure >= _threshold) then {
            _damage = _tickDamage;
            _damageStage = _forEachIndex;
        };
    } forEach (_profile getOrDefault ["damageThresholds", []]);

    private _previousStage = _previousStages getOrDefault [_key, -1];
    if (_showNotifications && {_damageStage > _previousStage} && {_profile getOrDefault ["notifyDamageStages", true]}) then {
        private _stageMessages = _profile getOrDefault ["damageStageMessages", []];
        private _stageMessage = _stageMessages param [_damageStage, _profile getOrDefault ["damageMessage", "Exposure is now causing physical harm."]];
        [
            _profile getOrDefault ["label", "Hazardous Area"],
            _stageMessage,
            "ERROR",
            format ["HAZARD_DAMAGE_%1", _key],
            _profile getOrDefault ["notificationDuration", missionNamespace getVariable ["Waldo_Hazard_NotificationDuration", 6]]
        ] call Waldo_fnc_FeatureNotifyLocal;
    };
    _previousStages set [_key, _damageStage];

    [_key, _profile, _inside, _intensity, _exposure, _damage, _aware] call Waldo_fnc_HazardAudioFeedback;

    if (_damage > 0) then {
        if (isClass (configFile >> "CfgPatches" >> "ace_medical")) then {
            private _bodyPart = selectRandom ["Head", "Body", "LeftArm", "RightArm", "LeftLeg", "RightLeg"];
            // "stab" is a documented ACE projectile type and produces a treatable medical wound.
            [player, _damage, _bodyPart, _profile getOrDefault ["damageType", "stab"]] call ace_medical_fnc_addDamageToUnit;
        } else {
            player setDamage (((damage player) + _damage) min 1);
        };
    };
    private _fatalAt = _profile getOrDefault ["fatalExposure", -1];
    if (_fatalAt >= 0 && {_exposure >= _fatalAt}) then {player setDamage 1};

    private _onTick = _profile getOrDefault ["onTick", {}];
    if (_onTick isEqualType "") then {_onTick = missionNamespace getVariable [_onTick, {}]};
    if (_onTick isEqualType {}) then {
        [player, _inside, _intensity, _exposure, _profile] call _onTick;
    };
} forEach +(missionNamespace getVariable ["Waldo_Hazard_Zones", []]);

// One combined status line per hazard type, not per contributing zone key. Visibility follows the
// grace clock above (presence-based, like a Geiger counter falling silent), not the exposure value
// itself - the physical exposure/effect keeps decaying at its own configured pace either way. Labelled
// by the hazard TYPE itself (e.g. "RADIATION"), not any one contributing zone's own narrative `label`
// - a single type routinely aggregates several differently-labelled zones/presets by design (see
// environmentConfig.sqf: "all radiation zones contribute to one accumulated dose"), so showing one
// arbitrary zone's label here would misrepresent a combined reading as if it came from just that zone.
{
    private _type = _x;
    (_typeAggregates get _type) params ["_label", "_exposureSum"];
    private _lastInside = _typeLastInside getOrDefault [_type, -1e6];
    if ((diag_tickTime - _lastInside) <= _graceSeconds) then {
        _activeText pushBack format ["%1: %2", _type, (_exposureSum toFixed 2)];
    };
} forEach (keys _typeAggregates);

// Drop grace-clock entries long past their window so this hashmap doesn't grow forever across a
// mission with many transient hazard types (moving emitters, ZEN-placed/removed zones, etc). Build
// a fresh replacement rather than deleteAt-while-iterating its own keys.
private _prunedTypeLastInside = createHashMap;
{
    if ((diag_tickTime - (_typeLastInside get _x)) <= (_graceSeconds * 20)) then {
        _prunedTypeLastInside set [_x, _typeLastInside get _x];
    };
} forEach (+(keys _typeLastInside));
_typeLastInside = _prunedTypeLastInside;

// Diagnostics must prove that spatial evaluation is actually advancing. Merely having a loop
// handle and a zone registry previously allowed a permanently inert evaluator to report ACTIVE.
missionNamespace setVariable ["Waldo_Hazard_LastEvaluation", [diag_tickTime, getPosATL player, _zoneDiagnostics]];

missionNamespace setVariable ["Waldo_Hazard_LocalExposure", _exposures];
missionNamespace setVariable ["Waldo_Hazard_LocalInside", _previousInside];
missionNamespace setVariable ["Waldo_Hazard_LocalTypeLastInside", _typeLastInside];
missionNamespace setVariable ["Waldo_Hazard_LocalDamageStages", _previousStages];
uiNamespace setVariable ["Waldo_Hazard_StatusText", _activeText joinString " | "];
[_activeText] call Waldo_fnc_HazardHud;
